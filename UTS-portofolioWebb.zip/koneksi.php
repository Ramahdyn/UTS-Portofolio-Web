<?php
$servername = "localhost";
$username = "ramq7973_web";
$password = "Bekicot87";
$dbname = "ramq7973_rama-portfolio";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>

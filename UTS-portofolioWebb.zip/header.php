    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>
    <?php
    $nama_file = basename($_SERVER['PHP_SELF']);
    ?>
    <!-- Header Section Begin -->
    <header class="header">
        <div class="container">
            <div class="row">
                <div class="col-lg-10">
                    <div class="header__nav__option">
                        <nav class="header__nav__menu mobile-menu">
                            <ul>
                                <li <?php if($nama_file == 'index.php') {?>class="active"<?php }?>><a href="./">Home</a></li>
                                <li <?php if($nama_file == 'about.php') {?>class="active"<?php }?>><a href="./about.php">About</a></li>
                                <li <?php if($nama_file == 'portfolio.php') {?>class="active"<?php }?>><a href="./portfolio.php">Portfolio</a></li>
                                <li <?php if($nama_file == 'services.php') {?>class="active"<?php }?>><a href="./services.php">Services</a></li>
                                <li <?php if($nama_file == 'contact.php') {?>class="active"<?php }?>><a href="./contact.php">Contact</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            <div id="mobile-menu-wrap"></div>
        </div>
    </header>
    <!-- Header End -->
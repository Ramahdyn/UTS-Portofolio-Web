<!DOCTYPE html>
<html lang="zxx">

<head>
    <?php require('meta.php');?>
</head>

<body>
    <?php 
    require('header.php');
    require('koneksi.php')
    ?>
    
    <!-- Breadcrumb Begin -->
    <div class="breadcrumb-option spad set-bg" data-setbg="img/breadcrumb-bg.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <?php
                        // Sesuaikan dengan nama halaman, misalnya 'about' untuk halaman About
                        $page = 'about';
                        $sql = "SELECT title, subtitle FROM breadcrumb WHERE page = '$page'";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            echo "<h2>" . $row['title'] . "</h2>";
                    ?>
                    <div class="breadcrumb__links">
                        <a href="index.php">Home</a>
                        <span><?php echo $row['subtitle']; ?></span>
                    </div>
                    <?php
                        } else {
                            echo "<h2>About us</h2>";
                    ?>
                    <div class="breadcrumb__links">
                        <a href="index.php">Home</a>
                        <span>About</span>
                    </div>
                    <?php
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- Breadcrumb End -->
    
   <!-- About Section Begin -->
    <section class="about spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="about__pic">
                    <div class="row">
                        <?php
                            // Ambil data gambar dari database
                            $sql = "SELECT image1, image2, image3 FROM about WHERE id = 1"; // Asumsikan ID adalah 1
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                        ?>
                        <div class="col-lg-6 col-md-6 col-sm-6">
                            <div class="about__pic__item about__pic__item--large set-bg"
                                data-setbg="img/about/<?php echo $row['image1']; ?>"></div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="about__pic__item set-bg" data-setbg="img/about/<?php echo $row['image2']; ?>"></div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="about__pic__item set-bg" data-setbg="img/about/<?php echo $row['image3']; ?>"></div>
                                </div>
                            </div>
                        </div>
                        <?php
                            }
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="about__text">
                    <?php
                        // Ambil data teks tentang dari database
                        $sql = "SELECT title, subtitle, description FROM about WHERE id = 1";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                    ?>
                    <div class="section-title">
                        <span><?php echo $row['subtitle']; ?></span>
                        <h2><?php echo $row['title']; ?></h2>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6">
                            <div class="services__item">
                                <div class="services__item__icon">
                                    <img src="img/icons/si-3.png" alt="">
                                </div>
                                <h4>Video distribution</h4>
                                <p>Whether you’re halfway through the editing process, or you.</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6">
                            <div class="services__item">
                                <div class="services__item__icon">
                                    <img src="img/icons/si-4.png" alt="">
                                </div>
                                <h4>Video hosting</h4>
                                <p>Whether you’re halfway through the editing process, or you.</p>
                            </div>
                        </div>
                    </div>
                    <div class="about__text__desc">
                        <p><?php echo $row['description']; ?></p>
                    </div>
                    <?php
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>
    </section>
    <!-- About Section End -->

    <!-- Testimonial Section Begin -->
    <section class="testimonial spad set-bg" data-setbg="img/testimonial-bg.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title center-title">
                    <span>Loved By Clients</span>
                    <h2>What clients say?</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="testimonial__slider owl-carousel">
                <?php
                    // Query untuk mengambil data testimonial
                    $sql = "SELECT name, occupation, testimonial, image FROM testimonials";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        // Looping untuk menampilkan data testimonial
                        while ($row = $result->fetch_assoc()) {
                ?>
                <div class="col-lg-4">
                    <div class="testimonial__item">
                        <div class="testimonial__text">
                            <p><?php echo $row['testimonial']; ?></p>
                        </div>
                        <div class="testimonial__author">
                            <div class="testimonial__author__pic">
                                <img src="img/testimonial/<?php echo $row['image']; ?>" alt="">
                            </div>
                            <div class="testimonial__author__text">
                                <h5><?php echo $row['name']; ?></h5>
                                <span><?php echo $row['occupation']; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                        }
                    }
                ?>
            </div>
        </div>
    </div>
    </section>
    <!-- Testimonial Section End -->

    <!-- Counter Section Begin -->
    <section class="counter">
    <div class="container">
        <div class="counter__content">
            <div class="row">
                <?php
                    // Query untuk mengambil data counter
                    $sql = "SELECT icon, counter_number, description FROM counters";
                    $result = $conn->query($sql);
                    $counter = 0; // Menambahkan variabel untuk melacak kolom
                    if ($result->num_rows > 0) {
                        // Menampilkan setiap item counter
                        while ($row = $result->fetch_assoc()) {
                            $counter++; // Menambah hitungan kolom
                ?>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="counter__item <?php echo ($counter == 2) ? 'second__item' : (($counter == 3) ? 'third__item' : (($counter == 4) ? 'four__item' : ''));?>">
                        <div class="counter__item__text">
                            <img src="img/icons/<?php echo $row['icon']; ?>" alt="">
                            <h2 class="counter_num"><?php echo $row['counter_number']; ?></h2>
                            <p><?php echo $row['description']; ?></p>
                        </div>
                    </div>
                </div>
                <?php
                        }
                    }
                ?>
            </div>
        </div>
    </div>
    </section>
    <!-- Counter Section End -->

    <!-- Team Section Begin -->
    <section class="team spad set-bg" data-setbg="img/team-bg.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title team__title">
                    <span>Nice to meet</span>
                    <h2>OUR Team</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <?php
                // Query untuk mengambil data tim
                $sql = "SELECT name, occupation, image, facebook_url, twitter_url, dribbble_url, instagram_url FROM team";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    // Menampilkan data tim dalam loop
                    $i = 0; // Untuk menentukan class item
                    while ($row = $result->fetch_assoc()) {
                        $i++;
                        // Mengatur class tambahan berdasarkan urutan
                        $itemClass = '';
                        if ($i == 1) {
                            $itemClass = ''; // Kelas default
                        } elseif ($i == 2) {
                            $itemClass = ' team__item--second'; // Kelas kedua
                        } elseif ($i == 3) {
                            $itemClass = ' team__item--third'; // Kelas ketiga
                        } elseif ($i == 4) {
                            $itemClass = ' team__item--four'; // Kelas keempat
                        }
            ?>
            <div class="col-lg-3 col-md-6 col-sm-6 p-0">
                <div class="team__item<?php echo $itemClass; ?> set-bg" data-setbg="img/team/<?php echo $row['image']; ?>">
                    <div class="team__item__text">
                        <h4><?php echo $row['name']; ?></h4>
                        <p><?php echo $row['occupation']; ?></p>
                        <div class="team__item__social">
                            <a href="<?php echo $row['facebook_url']; ?>"><i class="fa fa-facebook"></i></a>
                            <a href="<?php echo $row['twitter_url']; ?>"><i class="fa fa-twitter"></i></a>
                            <a href="<?php echo $row['dribbble_url']; ?>"><i class="fa fa-dribbble"></i></a>
                            <a href="<?php echo $row['instagram_url']; ?>"><i class="fa fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php
                    }
                }
            ?>
            <div class="col-lg-12 p-0">
                <div class="team__btn">
                    <a href="#" class="primary-btn">Meet Our Team</a>
                </div>
            </div>
        </div>
    </div>
    </section>
    <!-- Team Section End -->

    <?php include('footer.php');?>
</body>

</html>